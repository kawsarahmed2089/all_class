-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 29, 2016 at 01:47 PM
-- Server version: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `php_class`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `userid` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `address` text NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `usertype` varchar(50) NOT NULL,
  `employeeID` int(10) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userid`, `name`, `user_name`, `address`, `email`, `password`, `usertype`, `employeeID`) VALUES
(1, 'Debraj Chowdhury', '', '', 'debraj@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'Super Admin', 1001),
(2, 'Bijon Chakraborty', '', '', 'bijon@gmail.com', '202cb962ac59075b964b07152d234b70', 'Admin', 1002),
(3, 'Rajit Datta', '', '', 'rajit@gmail.com', '202cb962ac59075b964b07152d234b70', 'Admin', 1003),
(4, 'Debojyoty Chowhury', '', '', 'debjyoty@gmail.com', '202cb962ac59075b964b07152d234b70', 'Developer', 1004),
(5, 'Ripon Nayek', '', '', 'ripon@gmail.com', '202cb962ac59075b964b07152d234b70', 'Admin', 1005),
(6, 'Shawon Deb', '', '', 'shawondeb@gmail.com', '202cb962ac59075b964b07152d234b70', 'Sales', 1006),
(7, 'Sajal Khan', '', '', 'sajal@gmail.com', '202cb962ac59075b964b07152d234b70', 'Sales', 1007),
(8, 'Gobindo Malaker', '', '', 'gobindo@gmail.com', '202cb962ac59075b964b07152d234b70', 'Sales', 1008),
(9, 'Kawsar Ahmed', '', '', 'kawsar@gmail.com', '202cb962ac59075b964b07152d234b70', 'Developer', 1009),
(10, 'Abdullah Nahian', '', '', 'nahian@gmail.com', '202cb962ac59075b964b07152d234b70', 'Developer', 1010),
(11, 'Nazmul Hossain', '', '', 'nazmul@gmail.com', '202cb962ac59075b964b07152d234b70', 'Developer', 1011),
(12, 'Krishno Luhar', '', '', 'krishno@gmail.com', '202cb962ac59075b964b07152d234b70', 'Admin', 1012),
(13, 'Bishnu Komol Debnath', '', '', 'bishnu@gmail.com', '202cb962ac59075b964b07152d234b70', 'Super Admin', 1013),
(14, 'Abdulla Bin Malik', '', '', 'malik@gmail.com', '202cb962ac59075b964b07152d234b70', 'Developer', 1014),
(15, 'Sabbir Ahmed Shawon', '', '', 'sabbirs93@gmail.com', '202cb962ac59075b964b07152d234b70', 'Super Admin', 1015),
(16, 'Ujjwal Roy', '', '', 'ujjal@gmail.com', '202cb962ac59075b964b07152d234b70', 'Developer', 1016),
(17, 'Hangsabrata Bhattacharjee', '', '', 'po@gmail.com', 'c0b135fda922fa2e534b3c4e5e8b58e5', 'Admin', 1017),
(18, 'Mostafa Monowar Shaon', '', '', 'shaon@gmail.com', '202cb962ac59075b964b07152d234b70', 'Developer', 1018),
(19, 'Md.Asraful Alam', '', '', 'ashraful@gmail.com', '202cb962ac59075b964b07152d234b70', 'Developer', 1019),
(20, 'Ajoy Baidya', '', '', 'ajoy@gmail.com', '202cb962ac59075b964b07152d234b70', 'Sales', 1020),
(21, 'Soptorshi Bhattacharjee', '', '', 'soptorshi@gmail.com', '202cb962ac59075b964b07152d234b70', 'Admin', 1021),
(22, 'Sadia Tasmin', '', '', 'sadia@gmail.com', '202cb962ac59075b964b07152d234b70', 'Developer', 1022),
(23, 'Sanjoy dey', '', '', 'sanjoy@gmail.com', '202cb962ac59075b964b07152d234b70', 'Marketing', 1023),
(24, 'Sagar Sarker', '', '', 'sagar@gmail.com', '202cb962ac59075b964b07152d234b70', 'Marketing', 1024),
(25, 'Md.Ruhel Khan', '', '', 'ruhel@gmail.com', '202cb962ac59075b964b07152d234b70', 'Developer', 1025),
(26, 'Titu dey', '', '', 'titu@gmail.com', '202cb962ac59075b964b07152d234b70', 'Developer', 1026),
(27, 'Utpol Debnath', '', '', 'utpol@gmail.com', '202cb962ac59075b964b07152d234b70', 'Developer', 1027),
(28, 'Ujjal Bhattacharjee', '', '', 'ujjal-design@gmail.com', '202cb962ac59075b964b07152d234b70', 'Developer', 1028),
(29, 'Md.Kowsar Jahan Talukder', '', '', 'tarek@gmail.com', '202cb962ac59075b964b07152d234b70', 'Marketing', 1029),
(30, 'Porimol Baraik', '', '', 'porimol@gmail.com', '202cb962ac59075b964b07152d234b70', 'Admin', 1030),
(31, 'Md.Manirul Islam ', '', '', 'manirul@gmail.com', '202cb962ac59075b964b07152d234b70', 'Developer', 1031),
(32, 'Israth Jahan Sarkar', '', '', 'isratjahansarkar@gmail.com', '202cb962ac59075b964b07152d234b70', 'Super Admin', 1032),
(35, 'Faruk Ahmed', 'faruk_ahmed', 'Kumarpara', 'demo@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'Superadmin', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=36;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
